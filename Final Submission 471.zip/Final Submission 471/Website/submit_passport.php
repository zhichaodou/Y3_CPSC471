<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<style>
.airplane-image{
	background-image: url(/img/passport-2714675_960_720.jpg);
	height: 500px;
 	background-position: center;
	background-repeat: no-repeat;
  	background-size: cover;
	position: relative;
}
</style>
<head>
	<title>Submit Passport Details</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<div class="airplane-image">

<body>

	<div class="header">
		<h2>Submit Passport Details</h2>
	</div>
	
	<form method="post" action="submit_passport.php">
		<?php include('errors.php'); ?>
		<div class="inputs">
			<label>Passport ID</label>
			<input type="passport_id" name="passport_id">
		</div>
		<input type="file" name="passport_photo" id="passport_photo">
		<div class="inputs">
			<button type="submit" class="buttonClick" name="submit_passport">Submit</button>
		</div>
		<p>
			<a href="index.php">Go back</a>.
		</p>
	</form>

</body>
</div>
</html>