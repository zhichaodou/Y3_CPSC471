<?php include('server.php') ?>
<!DOCTYPE html>
<html>

<style>
.airplane-image{
	background-image: url(/img/airport-1822133_960_720.jpg);
	height: 500px;
 	background-position: center;
	background-repeat: no-repeat;
  	background-size: cover;
	position: relative;
}
</style>

<head>
	<title>Register Luggage</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<div class="airplane-image">

<body>

	<div class="header">
		<h2>Register Luggage</h2>
	</div>
	
	<form method="post" action="register_luggage.php">
		<?php include('errors.php'); ?>
		<div class="inputs">
			<label>Identification Number</label>
			<input type="id" name="id">
		</div>
		<div class="inputs">
			<label>Weight</label>
			<input type="weight" name="weight">
		</div>

		<div class="inputs">
			<button type="submit" class="buttonClick" name="register_luggage">Submit</button>
		</div>
		<p>
			<a href="index.php">Go back</a>.
		</p>
	</form>
</body>
</div>
</html>