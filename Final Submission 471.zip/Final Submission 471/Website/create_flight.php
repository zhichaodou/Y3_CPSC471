<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<style>
.airplane-image{
	background-image: url(/img/airport-1043636_960_720.jpg);
	height: 500px;
 	background-position: center;
	background-repeat: no-repeat;
  	background-size: cover;
	position: relative;
}
</style>


<head>
	<title>Create Flight</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<div class="airplane-image">

<body>

	<div class="header">
		<h2>Create Flight</h2>
	</div>
	
	<form method="post" action="create_flight.php">
		<?php include('errors.php'); ?>
		<div class="inputs">
			<label>Flight ID</label>
			<input type="id" name="id">
		</div>
		<div class="inputs">
			<label>Destination</label>
			<input type="dest" name="dest">
		</div>
		<div class="inputs">
			<label>Date</label>
			<input type="date" name="date">
		</div>
		<div class="inputs">
			<label>Time</label>
			<input type="time" name="time">
		</div>
		<div class="inputs">
			<label>Goods</label>
			<input type="goods" name="goods">
		</div>
		<div class="inputs">
			<label>Weight of Cargo</label>
			<input type="weight" name="weight">
		</div>
		<div class="inputs">
			<label>Type of Flight</label>
			<input type="type" name="type">
		</div>
		<div class="inputs">
			<label>Waypoints</label>
			<input type="waypoints" name="waypoints">
		</div>
		<div class="inputs">
			<label>Crusing Altitude</label>
			<input type="alt" name="alt">
		</div>
		<div class="inputs">
			<label>Cost</label>
			<input type="cost" name="cost">
		</div>


		<div class="inputs">
			<button type="submit" class="buttonClick" name="create_flight">Submit</button>
		</div>
		<p>
			<a href="index.php">Go back</a>.
		</p>
	</form>

</body>
</div>
</html>