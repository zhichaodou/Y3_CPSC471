<?php include('server.php') ?>
<!DOCTYPE html>
<html>

<style>
.airplane-image{
	background-image: url(/img/airport-731196_960_720.jpg);
	height: 500px;
 	background-position: center;
	background-repeat: no-repeat;
  	background-size: cover;
	position: relative;
}
</style>

<head>
	<title>Clear Customs</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<div class="airplane-image">
<body>

	<div class="header">
		<h2>Clear Customs</h2>
	</div>
	
	<form method="post" action="clear_customs.php">
		<?php include('errors.php'); ?>
		<div class="inputs">
			<label>Flight ID</label>
			<input type="id" name="id">
		</div>
		<div class="inputs">
			<button type="submit" class="buttonClick" name="clear_customs">Submit</button>
		</div>
		<p>
			<a href="index.php">Go back</a>.
		</p>
	</form>
</body>
</div>
</html>