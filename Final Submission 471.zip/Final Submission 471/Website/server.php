<?php
	session_start();

	// variable declaration
	$username = "";
	$email    = "";
	$errors = array();
	$_SESSION['success'] = "";

	// connect to database
	$db = mysqli_connect('localhost', 'Tim', 'tim', 'airport');

	// REGISTER USER
	if (isset($_POST['reg_user'])) {
		// receive all input values from the form
		$username = mysqli_real_escape_string($db, $_POST['username']);
		$password_1 = mysqli_real_escape_string($db, $_POST['password_1']);
		$password_2 = mysqli_real_escape_string($db, $_POST['password_2']);
		$type = mysqli_real_escape_string($db, $_POST['type']);


		// checks to errors (if no input was thrown)
		if (empty($username)) { array_push($errors, "Username is required"); }
		if (empty($password_1)) { array_push($errors, "Password is required"); }
		if ($type == '0') { array_push($errors, "Type is required"); }


		// no need to check is pass 2 is empty, since as long as pass1 and pass2 this will role out a notification
		if ($password_1 != $password_2) {
			array_push($errors, "The two passwords do not match");
		}

		// if no problems with register, finish registration
		$password = $password_1;
		if (count($errors) == 0) {
			if($type == '1'){
				$query = "INSERT INTO USERS (username, user_password , user_type)
					  	VALUES('$username', '$password', 'CLIENTS')";
				mysqli_query($db, $query);
				$query = "INSERT INTO CLIENTS (username, client_password , passport_id, no_fly_list)
					  	VALUES('$username', '$password', '0', 'FALSE')";
				mysqli_query($db, $query);
			}
			if($type == '2'){
				$query = "INSERT INTO USERS (username, user_password , user_type)
					  	VALUES('$username', '$password', 'GOVERNMENT')";
				mysqli_query($db, $query);

				$query = "INSERT INTO GOVERNMENT (username, gov_password)
					  	VALUES('$username', '$password')";
				mysqli_query($db, $query);
			}
			if($type == '3'){
				$query = "INSERT INTO USERS (username, user_password , user_type)
					  	VALUES('$username', '$password', 'AIRPORT_AUTHORITY')";
				mysqli_query($db, $query);

				$query = "INSERT INTO AIRPORT_AUTHORITY (username, authority_password)
					  	VALUES('$username', '$password')";
				mysqli_query($db, $query);
			}
			if($type == '4'){
				$query = "INSERT INTO USERS (username, user_password , user_type)
					  	VALUES('$username', '$password', 'AIRCRAFT_OWNER')";
				mysqli_query($db, $query);

				$query = "INSERT INTO AIRCRAFT_OWNERS (username, owner_password)
					  	VALUES('$username', '$password')";
				mysqli_query($db, $query);
			}

			$_SESSION['username'] = $username;
			$_SESSION['password'] = $password;
			header('location: login.php');
		}

	}
	// login in
	if (isset($_POST['login_user'])) {
		$username = mysqli_real_escape_string($db, $_POST['username']);
		$password = mysqli_real_escape_string($db, $_POST['password']);
		$type = mysqli_real_escape_string($db, $_POST['type']);


		//checks is any blanks
		if (empty($username)) {
			array_push($errors, "Username is required");
		}
		if (empty($password)) {
			array_push($errors, "Password is required");
		}
		if ($type == '0') {
			array_push($errors, "Type is required");
		}
		if ($type == '1') {
			$type = 'CLIENTS';
		}
		if ($type == '2') {
			$type = 'GOVERNMENT';
		}
		if ($type == '3') {
			$type = 'AIRPORT_AUTHORITY';
		}
		if ($type == '4') {
			$type = 'AIRCRAFT_OWNERS';
		}






		if (count($errors) == 0) {
			$query = "SELECT * FROM USERS WHERE username='$username' AND user_password='$password' AND user_type = '$type'";
			$results = mysqli_query($db, $query);

			if (mysqli_num_rows($results) == 1) {
				$_SESSION['username'] = $username;
				$_SESSION['password'] = $password;
				$_SESSION['success'] = "You are currently login";
				$_SESSION['type'] = $type;
				header('location: index.php');
			}else {
				array_push($errors, "Wrong username/password combination");
			}
		}
	}


	if (isset($_POST['client_book'])) {
		$flight_ID = mysqli_real_escape_string($db, $_POST['flight_ID']);
		$username = $_SESSION['username'];
		$password = $_SESSION['password'];
		//checks is any blank
		if (empty($flight_ID)) {
			array_push($errors, "Flight ID is required");
		}

		$query = "SELECT *
				FROM CLIENTS as c
					WHERE c.username = '$username' AND c.client_password = '$password' AND c.no_fly_list = 'TRUE'";
		$result = mysqli_query($db, $query);
		if (mysqli_num_rows($result) != 0) {
			array_push($errors, "You cannot book a flight since you are on the no fly list.");
		}


		if (count($errors) == 0) {
			$query = "INSERT INTO BOOKED (username, client_password, flight_id)
					  	VALUES('$username', '$password', '$flight_ID')";
			$result = mysqli_query($db, $query);
			if(!$result){
				array_push($errors, "Booking Failed");
			}
			else{
			header('location: index.php');
			}

		}

	}

	if (isset($_POST['register_luggage'])) {
		$id = mysqli_real_escape_string($db, $_POST['id']);
		$weight = mysqli_real_escape_string($db, $_POST['weight']);
		$username = $_SESSION['username'];
		$password = $_SESSION['password'];
		$passport_id = $_SESSION['passport_id'];

		//checks is any blanks
		if (empty($id)) {
			array_push($errors, "Identification Number is required");
		}

		if (count($errors) == 0) {
			$query = "INSERT INTO LUGGAGE (id, weight, username, client_password, client_passport_id)
					  	VALUES('$id', '$weight', '$username', '$password', '$passport_id')";
			$result = mysqli_query($db, $query);
			if(!$result){
				array_push($errors, "Registration Failed");
			}
			else{
			header('location: index.php');
			}

		}
	}


	if (isset($_POST['submit_passport'])) {
		$passport_id = mysqli_real_escape_string($db, $_POST['passport_id']);
		$_SESSION['passport_id'] = $passport_id;
		$image = addslashes(file_get_contents($_FILES['passport_photo']['tmp_name']));
		$username = $_SESSION['username'];
		$password = $_SESSION['password'];

		//checks is any blanks
		if (empty($passport_id)) {
			array_push($errors, "Passport ID is required");
		}


		if (count($errors) == 0) {
			$query = "UPDATE CLIENTS
					SET passport_id = '$passport_id'
						WHERE username = '$username' AND client_password = '$password'";
			mysqli_query($db, $query);
			$query = "INSERT INTO PASSPORT(passport_id, photo)
					  	VALUES('$passport_id', '$image')";
			mysqli_query($db, $query);
			header('location: index.php');

		}
	}

	if (isset($_POST['clear_customs'])) {
		$id = mysqli_real_escape_string($db, $_POST['id']);
		$username = $_SESSION['username'];
		$password = $_SESSION['password'];

		//checks is any blanks
		if (empty($id)) {
			array_push($errors, "Flight ID is required");
		}


		if (count($errors) == 0) {
			$query = "INSERT INTO CLEARED_CUSTOMS (gov_username, gov_password, flight_id)
					  	VALUES('$username', '$password', '$id')";
			$result = mysqli_query($db, $query);
			if(!$result){
				array_push($errors, "Registration Failed");
			}
			else{
			header('location: index.php');
			}

		}
	}

	if (isset($_POST['search_flight'])) {
		$date = mysqli_real_escape_string($db, $_POST['date']);
		$dest = mysqli_real_escape_string($db, $_POST['dest']);
		//checks is any blanks
		if (empty($dest)) {
			array_push($errors, "Destination is required");
		}


		if (count($errors) == 0) {
			$query = "SELECT f.flight_id, f.destination, f.flight_date, f.flight_time, p.cost
					FROM FLIGHTS as f, PLANS_FOR as p
						WHERE f.flight_date = '$date' AND f.destination = '$dest' AND p.flight_id = f.flight_id and f.flight_type = 'COMMERCIAL'";
			$result = mysqli_query($db, $query);
			echo "<form>";
			echo "<br>";
			echo "<table border='1'>";
			echo "<tr><td>Flight ID</td><td>Destination</td><td>Flight Date</td><td>Flight Time</td><td>Cost</td><tr>";

			while ($row = mysqli_fetch_assoc($result)) {
   				echo "<tr>";
    				foreach ($row as $field => $value) {
        			echo "<td>" . $value . "</td>";
    				}
   			 echo "</tr>";
			}
			echo "</table>";
			echo "</form>";
		}
	}

	if (isset($_POST['track_pass'])) {
		$name = mysqli_real_escape_string($db, $_POST['username']);
		//checks is any blanks
		if (empty($name)) {
			array_push($errors, "Username is required");
		}


		if (count($errors) == 0) {
			$query = "SELECT b.username, b.flight_id, f.flight_date, f.estimate_arrival
					FROM BOOKED as b, FLIGHTS as f
						where b.username = '$name' AND b.flight_id = f.flight_id AND f.arrival is NULL
				UNION
				SELECT b.username, b.flight_id, f.flight_date, f.arrival
					FROM BOOKED as b, FLIGHTS as f
						where b.username = '$name' AND b.flight_id = f.flight_id AND f.arrival IS NOT NULL";
			$result = mysqli_query($db, $query);
			echo "<form>";
			echo "<br>";
			echo "<table border='1'>";
			echo "<tr><td>Username</td><td>Flight_ID</td><td>Flight Date</td><td>Arrival</td>";
			while ($row = mysqli_fetch_assoc($result)) {
   				echo "<tr>";
    				foreach ($row as $field => $value) {
        			echo "<td>" . $value . "</td>";
    				}
   			 echo "</tr>";
			}
			echo "</table>";
			echo "</form>";
		}
	}

	if (isset($_POST['search_security'])) {
		$name = mysqli_real_escape_string($db, $_POST['name']);
		//checks is any blanks
		if (empty($name)) {
			array_push($errors, "Name is required");
		}


		if (count($errors) == 0) {
			$query = "SELECT *
					FROM PERSONNEL
						WHERE p_name = '$name' AND p_type = 'SECURITY'";
			$result = mysqli_query($db, $query);
			echo "<body>";
			echo "<br>";
			echo "<table border='1'>";
			while ($row = mysqli_fetch_assoc($result)) {
   				echo "<tr>";
    				foreach ($row as $field => $value) {
        			echo "<td>" . $value . "</td>";
    				}
   			 echo "</tr>";
			}
			echo "</table>";
			echo "</body>";
		}
	}

	if (isset($_POST['register_security'])) {
		$ssn = mysqli_real_escape_string($db, $_POST['ssn']);
		$name = mysqli_real_escape_string($db, $_POST['name']);
		$address = mysqli_real_escape_string($db, $_POST['address']);
		$phone = mysqli_real_escape_string($db, $_POST['phone']);
		$username = $_SESSION['username'];
		$password = $_SESSION['password'];

		//checks is any blanks
		if (empty($ssn)) {
			array_push($errors, "SSN is required");
		}
		if (empty($name)) {
			array_push($errors, "Name is required");
		}

		if (empty($address)) {
			array_push($errors, "Address is required");
		}

		if (empty($phone)) {
			array_push($errors, "Phone is required");
		}



		if (count($errors) == 0) {
			$query = "INSERT INTO PERSONNEL(`ssn`,`p_name`,`address`,`phone_number`,`p_type`)
					VALUES('$ssn', '$name', '$address', '$phone', 'SECURITY')";
			mysqli_query($db, $query);

			$query = "INSERT INTO EMPLOYS('gov_username', 'gov_password', 'ssn')
					VALUES('$username', '$password', '$ssn')";
			mysqli_query($db, $query);

			header('location: index.php');

		}
	}

	if (isset($_POST['register_aircraft'])) {
		$serial = mysqli_real_escape_string($db, $_POST['serial']);
		$years = mysqli_real_escape_string($db, $_POST['years']);
		$model = mysqli_real_escape_string($db, $_POST['model']);
		$manufacturer = mysqli_real_escape_string($db, $_POST['manufacturer']);
		$weight = mysqli_real_escape_string($db, $_POST['weight']);
		$username = $_SESSION['username'];
		$password = $_SESSION['password'];

		//checks is any blanks
		if (empty($serial)) {
			array_push($errors, "Serial Number is required");
		}

		if (empty($years)) {
			array_push($errors, "Year is required");
		}

		if (empty($model)) {
			array_push($errors, "Model is required");
		}

		if (empty($manufacturer)) {
			array_push($errors, "Manufacturer is required");
		}

		if (empty($weight)) {
			array_push($errors, "Weight is required");
		}

		if (count($errors) == 0) {
			$query = "INSERT INTO `airport`.`AIRCRAFT`(`serial_number`,`years_in_service`,`model`,`manufacturer`,`weight_capacity`,`x_coordinate`,`y_coordinate`,`owner_username`,`owner_password`)
					VALUES('$serial', '$years', '$model', '$manufacturer', '$weight', '0', '0', '$username', '$password')";
			mysqli_query($db, $query);
			header('location: index.php');

		}
	}

	if (isset($_POST['list_aircraft'])) {
		$username = $_SESSION['username'];
		$password = $_SESSION['password'];

		if (count($errors) == 0) {
			$query = "SELECT a.serial_number, a.years_in_service, a.model, a.weight_capacity, l.location_name, l.location_number
					FROM AIRCRAFT as a, LOCATION as l
						WHERE a.owner_username = '$username' AND a.owner_password = '$password' AND a.x_coordinate = l.x_coordinate AND a.y_coordinate = l.y_coordinate";
			$result = mysqli_query($db, $query);
			echo "<form>";
			echo "<br>";
			echo "<table border='1'>";
			echo "<tr><td>Serial Number</td><td>Years in Service</td><td>Model</td><td>Weight Capacity</td><td>Location Name</td><td>Location Number</td>";
			while ($row = mysqli_fetch_assoc($result)) {
   				echo "<tr>";
    				foreach ($row as $field => $value) {
        			echo "<td>" . $value . "</td>";
    				}
   			 echo "</tr>";
			}
			echo "</table>";
			echo "</form>";
		}
	}


	if (isset($_POST['add_weather'])) {
		$date = mysqli_real_escape_string($db, $_POST['date']);
		$time = mysqli_real_escape_string($db, $_POST['time']);
		$temperature = mysqli_real_escape_string($db, $_POST['temperature']);
		$cloudCover = mysqli_real_escape_string($db, $_POST['cloudCover']);
		$visability = mysqli_real_escape_string($db, $_POST['visability']);
		$username = $_SESSION['username'];
		$password = $_SESSION['password'];


		//checks is any blanks
		if (empty($date)) {
			array_push($errors, "Please state the weather date");
		}
		if (empty($time)) {
			array_push($errors, "Please state the weathertime");
		}

		if (empty($temperature)) {
			array_push($errors, "Please state the weather temperature");
		}

		if (empty($cloudCover)) {
			array_push($errors, "Please state the cloud cover");
		}

		if (empty($visability)) {
			array_push($errors, "Please state the visability");
		}



		if (count($errors) == 0) {
			$query = "INSERT INTO WEATHER_DATA(weather_date,weather_time, authority_username, authority_password, temperature, cloud_cover, visability)
					VALUES('$date', '$time', '$username', '$password', '$temperature', '$cloudCover', '$visability')";
			mysqli_query($db, $query);

			header('location: index.php');

		}
	}

	if (isset($_POST['get_weather'])) {
			$query = "SELECT * FROM WEATHER_DATA";
			$result = mysqli_query($db, $query);
			echo "<form>";
			echo "<br>";
			echo "<table border='1'>";
			echo "<tr><td>Date</td><td>Time</td><td>Temperature</td><td>Cloud Cover</td><td>Visability</td></tr>";
			while ($row = mysqli_fetch_assoc($result)) {
   				echo "<tr><td>{$row['weather_date']}</td><td>{$row['weather_time']}</td><td>{$row['temperature']}</td><td>{$row['cloud_cover']}</td><td>{$row['visability']}</td><tr>";
			}
			echo "</table>";
			echo "</form>";
	}

	if(isset($_POST['get_location'])) {
			$query = "SELECT *
					FROM LOCATION";
			$result = mysqli_query($db, $query);
			echo "<form>";
			echo "<br>";
			echo "<table border='1'>";
			echo "<tr><td>x_coordinate</td><td>y_coordinate</td><td>location_name</td><td>location_number</td><td>location_type</td><tr>";
			while ($row = mysqli_fetch_assoc($result)) {
   				echo "<tr><td>{$row['x_coordinate']}</td><td>{$row['y_coordinate']}</td><td>{$row['location_name']}</td><td>{$row['location_number']}</td><td>{$row['location_type']}</td><tr>";
			}
			echo "</table>";
			echo "</form>";

	}

	if (isset($_POST['update_location'])) {
		$serial = mysqli_real_escape_string($db, $_POST['serial']);
		$x = mysqli_real_escape_string($db, $_POST['x']);
		$y = mysqli_real_escape_string($db, $_POST['y']);

		//checks is any blanks
		if (empty($serial)) {
			array_push($errors, "Serial Number is Required");
		}
		if (empty($x)) {
			array_push($errors, "X-Coordinate is Required");
		}

		if (empty($y)) {
			array_push($errors, "Y-Coordinate is Required");
		}



		if (count($errors) == 0) {
			$query = "UPDATE AIRCRAFT
					SET x_coordinate = '$x', y_coordinate = '$y'
						WHERE serial_number = '$serial'";
			$result = mysqli_query($db, $query);

			if(!$result){
				array_push($errors, "Update Failed");
			}
			else{
			header('location: index.php');
			}

		}
	}

	if (isset($_POST['view_supplier'])) {
		$type = mysqli_real_escape_string($db, $_POST['type']);
		//checks is any blanks
		if (empty($type)) {
			array_push($errors, "Type is required");
		}


		if (count($errors) == 0) {
			$query = "SELECT username, supplier_id, company_name, supplier_type
					FROM SUPPLIERS
						WHERE supplier_type = '$type'";
			$result = mysqli_query($db, $query);
			echo "<form>";
			echo "<br>";
			echo "<table border='1'>";
			echo "<tr><td>Username</td><td>ID</td><td>Company Name</td><td>Supplier Type</td><tr>";
			while ($row = mysqli_fetch_assoc($result)) {
    				foreach ($row as $field => $value) {
        			echo "<td>" . $value . "</td>";
    				}
   			 echo "</tr>";
			}
			echo "</table>";
			echo "</form>";
		}
	}

	if (isset($_POST['create_flight'])) {
		$id = mysqli_real_escape_string($db, $_POST['id']);
		$dest = mysqli_real_escape_string($db, $_POST['dest']);
		$date = mysqli_real_escape_string($db, $_POST['date']);
		$time = mysqli_real_escape_string($db, $_POST['time']);
		$goods = mysqli_real_escape_string($db, $_POST['goods']);
		$weight = mysqli_real_escape_string($db, $_POST['weight']);
		$type = mysqli_real_escape_string($db, $_POST['type']);
		$waypoints = mysqli_real_escape_string($db, $_POST['waypoints']);
		$alt = mysqli_real_escape_string($db, $_POST['alt']);
		$cost = mysqli_real_escape_string($db, $_POST['cost']);





		$username = $_SESSION['username'];
		$password = $_SESSION['password'];
		$passport_id = $_SESSION['passport_id'];

		//checks is any blanks
		if (empty($id)) {
			array_push($errors, "Identification Number is required");
		}

		if (count($errors) == 0) {
			$query = "INSERT INTO PLANS_FOR(flight_id, username, owner_password, waypoints, cruising_altitude, cost, flight_type)
					VALUES('$id', '$username', '$password', '$waypoints', '$alt', '$cost', '$type')";

			$result = mysqli_query($db, $query);
			if(!$result){
				array_push($errors, "Registration Failed");
			}
			else{
			$query = "INSERT INTO FLIGHTS (flight_id, destination, flight_date, flight_time, goods, weight_of_cargo, flight_type, owner_username, owner_password)
					VALUES ('$id', '$dest', '$date', '$time', '$goods', '$weight', '$type', '$username', '$password')";

			$result = mysqli_query($db, $query);
			}
			if(!$result){
				array_push($errors, "Registration Failed");
			}
			else{
			header('location: index.php');
			}

		}
	}


?>
