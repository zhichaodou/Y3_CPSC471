<?php
$servername = "localhost";
$username = "Tim";
$password = "tim";

// Create connection
$conn = mysqli_connect('localhost', 'Tim', 'tim', 'registration');


// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";
?> 