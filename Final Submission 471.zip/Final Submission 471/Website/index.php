<?php 
	session_start(); 

	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header("location: login.php");
	}

?>
<!DOCTYPE html>
<html>

<style>
.airplane-image{
	background-image: url(/img/yxGqQnSp3zHtOszMSQNw_azulobscura4.png);
	height: 500px;
 	background-position: center;
	background-repeat: no-repeat;
  	background-size: cover;
	position: relative;
}

li{
 display: inline-block;
}
li a{
 text-decoration: none;
 display: inline-block;
 color: #000000;
 font-family: Source Sans Pro;
 font-weight: lighter;
 font-size: 15px;
 padding: 0 10px;

}
.fancy-line::after{
 content: ' ';
 display: block;
 width: 0;
 height: 2px;
 background: #000000;
 transition: width .3s;
}
.fancy-line:hover::after{
 width: 100%;
 transition: width .3s;
}?

</style>

<head>
	<title>Airport database</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<div class="airplane-image">
<body>

	<div class="header">
		<h2>Home Page</h2>
	</div>
	<div class="content">

		<?php if (isset($_SESSION['success'])) : ?>
			<div class="error success" >
				<h3>
					<?php 
						echo $_SESSION['success']; 
						unset($_SESSION['success']);
					?>
				</h3>
			</div>
		<?php endif ?>

		<?php  if (isset($_SESSION['username'])) : ?>
			<div>Welcome <strong><?php echo $_SESSION['username']; ?></strong>
			</div>
		<?php endif ?>

		<?php  if (!isset($_SESSION['username'])) : ?>
			<div>
			Welcome <strong><?php echo Guest; ?></strong>
			</div>

			<div>
			<li><a href="search_flight.php" class="fancy-line">Search for Flight</a></li>
			<br><li><a href="track_pass.php" class="fancy-line">Track Passenger</a></li>
			</div>
		<?php endif ?>



		<?php  if ($_SESSION['type'] == 'CLIENTS') : ?>
			<div>
				<li><a href="search_flight.php" class="fancy-line">Search for Flight</a></li>
				<br><li><a href="submit_passport.php" class="fancy-line">Submit Passport Infomation</a></li>
				<br><li><a href="client_book.php" class="fancy-line">Book Flight</a></li>
				<br><li><a href="register_luggage.php" class="fancy-line">Register Luggage</a></li>
				<br><li><a href="track_pass.php" class="fancy-line">Track Passenger</a></li>


			</div>
		<?php endif ?>

		<?php  if ($_SESSION['type'] == 'GOVERNMENT') : ?>
			<div>
				<li><a href="clear_customs.php" class="fancy-line">Clear planes through customs</a></li>
				<br><li><a href="search_security.php" class="fancy-line">Search for Security Personnel</a></li>
				<br><li><a href="register_security.php" class="fancy-line">Register Security Personnel</a></li>
			</div>
		<?php endif ?>


		<?php  if ($_SESSION['type'] == 'AIRPORT_AUTHORITY') : ?>
			<div>
				<li><a href="showAddWeather.php" class="fancy-line">View/Add Weather Data</a></li>
				<br><li><a href="getLocation.php" class="fancy-line">View Location Details</a></li>
				<br><li><a href="update_location.php" class="fancy-line">Update Aircraft Location</a></li>
				<br><li><a href="view_supplier.php" class="fancy-line">View Supplier by Catagory</a></li>

			</div>
		<?php endif ?>


		<?php  if ($_SESSION['type'] == 'AIRCRAFT_OWNERS') : ?>
			<div>
				<li><a href="register_aircraft.php" class="fancy-line">Register Aircraft</a></li>
				<br><li><a href="create_flight.php" class="fancy-line">Create Flight</a></li>
				<br><li><a href="list_aircraft.php" class="fancy-line">List Aircraft Inventory</a></li>
			</div>
		<?php endif ?>
		<br><p> <a href="index.php?logout='1'" class="buttonClick">logout</a> </p>

	</div>	
</body>
</div>
</html>