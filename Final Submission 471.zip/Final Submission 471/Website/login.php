<?php include('server.php') ?>
<!DOCTYPE html>
<html>

<style>
.airplane-image{
	background-image: url(/img/vjmcFlALk9Dsp2Xe4-2i_azulobscura15.png);
	height: 500px;
 	background-position: center;
	background-repeat: no-repeat;
  	background-size: cover;
	position: relative;
}
</style>

<head>
	<title> Airport database</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<div class="airplane-image">
<body>
	<div class="header">
		<h2> Airport Login</h2>
	</div>
	
	<form method="post" action="login.php">
		<?php include('errors.php'); ?>
		<div class="inputs">
			<label>Username</label>
			<input type="text" name="username" >
		</div>
		<div class="inputs">
			<label>Password</label>
			<input type="password" name="password">
		</div>
		<label>I am a</label>
		<select id="Type" name="type">                      
		<option value="0">--Select Type--</option>
		<option value="1">Client</option>
		<option value="2">Government Agent</option>
		<option value="3">Airport Authority Agent</option>
		<option value="4">Aircraft Owner</option>
		</select>
		<div class="inputs">
			<button type="submit" class="buttonClick" name="login_user">Login</button>
		</div>
		<p>
			Not a member? Click <a href="register.php">here</a> to make an account.
		</p>
		<p>
			Or sign in as <a href="index.php">guest</a>.
		</p>


	</form>
	</div>

</body>
</div>
</html>