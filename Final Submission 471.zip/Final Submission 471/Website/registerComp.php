<!DOCTYPE html>
<html>

<style>
.airplane-image{
	background-image: url(/img/terminal-1210006_960_720.jpg);
	height: 500px;
 	background-position: center;
	background-repeat: no-repeat;
  	background-size: cover;
	position: relative;
}
</style>

<head>
	<title>Airport database</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<div class="airplane-image">

<body>
	<div class="header">
		<h2>Registration Successful!</h2>
	</div>
	<div class="content">
		<p>
			Click <a href="login.php">here</a> to sign in.
		</p>
	</div>
	
</body>
</div>
</html>