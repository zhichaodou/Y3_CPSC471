<?php include('server.php') ?>
<!DOCTYPE html>
<html>

<style>
.airplane-image{
	background-image: url(/img/plane-170272_960_720.jpg);
	height: 500px;
 	background-position: center;
	background-repeat: no-repeat;
  	background-size: cover;
	position: relative;
}
</style>

<head>
	<title>View Supplier by Category</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<div class="airplane-image">

<body>

	<div class="header">
		<h2>View Supplier by Category</h2>
	</div>
	
	<form method="post" action="view_supplier.php">
		<?php include('errors.php'); ?>
		<div class="inputs">
			<label>Supplier Type</label>
			<input type="type" name="type">
		</div>

		<div class="inputs">
			<button type="submit" class="buttonClick" name="view_supplier">Submit</button>
		</div>
		<p>
			<a href="index.php">Go back</a>.
		</p>
	</form>
</body>
</div>
</html>