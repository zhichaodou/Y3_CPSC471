<?php include('server.php') ?>
<!DOCTYPE html>
<html>

<style>
.airplane-image{
	background-image: url(/img/airport-691047_960_720.jpg);
	height: 500px;
 	background-position: center;
	background-repeat: no-repeat;
  	background-size: cover;
	position: relative;
}
</style>


<head>
	<title>Registration system PHP and MySQL</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<div class="airplane-image">

<body>
	<div class="header">
		<h2>Make an account</h2>
	</div>
	<form method="post" action="register.php">
		<?php include('errors.php'); ?>

		<div class="inputs">
			<label>Username</label>
			<input type="text" name="username" value="<?php echo $username; ?>">
		</div>
		<div class="inputs">
			<label>Password</label>
			<input type="password" name="password_1">
		</div>
		<div class="inputs">
			<label>Confirm Password</label>
			<input type="password" name="password_2">
		</div>
		<select id="Type" name="type">                      
		<option value="0">--Select Type--</option>
		<option value="1">Client</option>
		<option value="2">Government Agent</option>
		<option value="3">Airport Authority Agent</option>
		<option value="4">Aircraft Owner</option>
		</select>
		<div class="inputs">
			<button type="submit" class="buttonClick" name="reg_user">Register</button>
		</div>
		<p>
			Already have an account? Click <a href="login.php">here</a> to sign in.
		</p>
	</form>
</body>
</div>
</html>