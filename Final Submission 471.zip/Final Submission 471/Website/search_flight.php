<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<style>
.airplane-image{
	background-image: url(/img/london-726443_960_720.jpg);
	height: 500px;
 	background-position: center;
	background-repeat: no-repeat;
  	background-size: cover;
	position: relative;
}
</style>
<head>
	<title>Search for Flights</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<div class="airplane-image">

<body>

	<div class="header">
		<h2>Search for Flights</h2>
	</div>
	
	<form method="post" action="search_flight.php">
		<?php include('errors.php'); ?>
		<div class="inputs">
			<label>Date</label>
			<input type="date" name="date">
		</div>
		<div class="inputs">
			<label>Destination</label>
			<input type="dest" name="dest">
		</div>

		<div class="inputs">
			<button type="submit" class="buttonClick" name="search_flight">Submit</button>
		</div>
		<p>
			<a href="index.php">Go back</a>.
		</p>
	</form>

</body>
</div>
</html>