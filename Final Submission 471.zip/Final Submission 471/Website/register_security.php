<?php include('server.php') ?>
<!DOCTYPE html>
<html>

<style>
.airplane-image{
	background-image: url(/img/building-2603781_960_720.jpg);
	height: 500px;
 	background-position: center;
	background-repeat: no-repeat;
  	background-size: cover;
	position: relative;
}
</style>

<head>
	<title>Register Security</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<div class="airplane-image">

<body>

	<div class="header">
		<h2>Register Security</h2>
	</div>
	
	<form method="post" action="register_security.php">
		<?php include('errors.php'); ?>
		<div class="inputs">
			<label>SSN</label>
			<input type="ssn" name="ssn">
		</div>
		<div class="inputs">
			<label>Name</label>
			<input type="name" name="name">
		</div>
		<div class="inputs">
			<label>Address</label>
			<input type="address" name="address">
		</div>
		<div class="inputs">
			<label>Phone</label>
			<input type="phone" name="phone">
		</div>



		<div class="inputs">
			<button type="submit" class="buttonClick" name="register_security">Submit</button>
		</div>
		<p>
			<a href="index.php">Go back</a>.
		</p>
	</form>
</body>
</div>
</html>