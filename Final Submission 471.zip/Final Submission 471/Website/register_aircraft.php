<?php include('server.php') ?>
<!DOCTYPE html>
<html>

<style>
.airplane-image{
	background-image: url(/img/airplane-2037961_960_720.jpg);
	height: 500px;
 	background-position: center;
	background-repeat: no-repeat;
  	background-size: cover;
	position: relative;
}
</style>


<head>
	<title>Register Aircraft</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<div class="airplane-image">

<body>

	<div class="header">
		<h2>Register Aircraft</h2>
	</div>
	
	<form method="post" action="register_aircraft.php">
		<?php include('errors.php'); ?>
		<div class="inputs">
			<label>Serial Number</label>
			<input type="serial" name="serial">
		</div>
		<div class="inputs">
			<label>Years in Service</label>
			<input type="years" name="years">
		</div>
		<div class="inputs">
			<label>Model</label>
			<input type="model" name="model">
		</div>
		<div class="inputs">
			<label>Manufacturer</label>
			<input type="manufacturer" name="manufacturer">
		</div>
		<div class="inputs">
			<label>Weight Capacity</label>
			<input type="weight" name="weight">
		</div>

		<div class="inputs">
			<button type="submit" class="buttonClick" name="register_aircraft">Submit</button>
		</div>
		<p>
			<a href="index.php">Go back</a>.
		</p>
	</form>
</body>
</div>
</html>