<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<style>
.airplane-image{
	background-image: url(/img/airport-1043636_960_720.jpg);
	height: 500px;
 	background-position: center;
	background-repeat: no-repeat;
  	background-size: cover;
	position: relative;
}
</style>

<head>
	<title>Search for Flights</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<div class="airplane-image">

<body>
<div class="header">
		<h2>Show or Add Weather</h2>
	</div>

<form method="post" action="showAddWeather.php">
	<p> Add weather data:</p>
	<?php include('errors.php'); ?>
		<div class="inputs">
			<label>Date</label>
			<input type="date" name="date">
		</div>

		<div class="inputs">
			<label>Time</label>
			<input type="time" name="time">
		</div>

		<div class="inputs">
			<label>Temperature</label>
			<input type="temperature" name="temperature">
		</div>

		<div class="inputs">
			<label>Cloud Cover</label>
			<input type="cloudCover" name="cloudCover">
		</div>

		<div class="inputs">
			<label>Visability</label>
			<input type="visability" name="visability">
		</div>

	<div class="inputs">
			<button type="submit" class="buttonClick" name="add_weather">Submit</button>
	</div>

	<p> Get weather data: </p>
	<div class="inputs">
			<button type="submit" class="buttonClick" name="get_weather">Request</button>
	</div>


	<p>  <a href="index.php">Go back</a>. </p>
</form>


</body>
</div>
</html>