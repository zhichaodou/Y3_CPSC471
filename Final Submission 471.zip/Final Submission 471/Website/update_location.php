<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<style>
.airplane-image{
	background-image: url(/img/airplane-2037961_960_720.jpg);
	height: 500px;
 	background-position: center;
	background-repeat: no-repeat;
  	background-size: cover;
	position: relative;
}
</style>

<head>
	<title>Update Aircraft Location</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<div class="airplane-image">

<body>

	<div class="header">
		<h2>Update Aircraft Location</h2>
	</div>
	
	<form method="post" action="update_location.php">
		<?php include('errors.php'); ?>
		<div class="inputs">
			<label>Serial Number</label>
			<input type="serial" name="serial">
		</div>

		<div class="inputs">
			<label>X-Coordinate</label>
			<input type="x" name="x">
		</div>
		<div class="inputs">
			<label>Y-Coordinate</label>
			<input type="y" name="y">
		</div>

		<div class="inputs">
			<button type="submit" class="buttonClick" name="update_location">Submit</button>
		</div>
		<p>
			<a href="index.php">Go back</a>.
		</p>
	</form>
</body>
</div>
</html>